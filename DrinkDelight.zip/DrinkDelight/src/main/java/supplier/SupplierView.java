package supplier;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class SupplierView 
{
	public static void addDetail()
	{
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the Supplier Id");
	String supplierId = sc.nextLine();
	System.out.println("Enter the Supplier Name");
	String supplierName = sc.nextLine();
	System.out.println("Enter the Supplier email");
	String supplierEmail = sc.nextLine();
	System.out.println("Enter the Supplier phone");
	String supplierPhone = sc.nextLine();
	System.out.println("Enter the Supplier RawId");
	String supplierRawId = sc.nextLine();

	new SupplierControl().fun(supplierId,supplierName,supplierEmail,supplierPhone,supplierRawId);


	}
	public static void file()
	{
	ArrayList <SupplierModel> arr=new ArrayList();
	SupplierModel rm=null;
	try {
	FileOutputStream fos = new FileOutputStream("C:\\new\\d.txt");
	ObjectOutputStream oos = new ObjectOutputStream(fos);
	oos.writeObject(arr);
	oos.close();
	fos.close();
	} catch (Exception e) {
	e.printStackTrace();
	}
	}

	public static void main(String[] args) {
	//file();
	addDetail();



	}
}
