package placeOrder;

public class ExceptionDate extends Exception
{
	@Override
	public String toString() 
	{
		return "Can't Enter a empty Date";
	}
}
