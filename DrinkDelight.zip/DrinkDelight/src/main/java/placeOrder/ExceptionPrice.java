package placeOrder;

public class ExceptionPrice extends Exception
{
	@Override
	public String toString() 
	{
		return "Please enter valid amount";
	}
}
