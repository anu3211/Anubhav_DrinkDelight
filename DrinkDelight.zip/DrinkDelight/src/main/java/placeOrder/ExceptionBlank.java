package placeOrder;

public class ExceptionBlank extends Exception
{

	@Override
	public String toString() 
	{
		return "Can't Enter a empty Id";
	}
	
}
