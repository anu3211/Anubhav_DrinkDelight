package Order;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ManagerMain 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		List<Manager> list = new ArrayList<Manager>();
		
		list.add(new Manager("EC16004","Anubhav","Sharma","ankit"));
		list.add(new Manager("EC16063","Ankit","Singh","anubhav"));
		
	}
}
