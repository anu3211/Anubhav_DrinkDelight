package Order;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class DistributorControl 
{
	public void fun(String distributorId, String distributorName, String distributorEmail, String distributorPhoneNo)
		{

			ArrayList<Distributor> arr=new ArrayList();
			Distributor r = new Distributor(distributorId,distributorName,distributorEmail,distributorPhoneNo);
			try
			{
			FileInputStream fi = new FileInputStream(new File("C:\\new\\a.txt"));
			ObjectInputStream oi = new ObjectInputStream(fi);
			arr=(ArrayList) oi.readObject();
			oi.close();
			}
			catch(Exception e)
			{
			System.out.println("File Not Found");
			}

			try
			{
			FileOutputStream fos = new FileOutputStream("C:\\new\\a.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(arr);
			oos.close();
			}
			catch(Exception e)
			{
			System.out.println("something went wrong");
			}
}
}
