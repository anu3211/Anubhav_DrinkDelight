package Order;

public class Manager 
{
	private String managaerId;
	private String firstName;
	private String lastName;
	private String password;
	
	public Manager(String managaerId, String firstName, String lastName, String password) {
		super();
		this.managaerId = managaerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
	}
	
	public String getManagaerId() {
		return managaerId;
	}

	public void setManagaerId(String managaerId) {
		this.managaerId = managaerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
