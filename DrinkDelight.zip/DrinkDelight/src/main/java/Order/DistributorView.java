package Order;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class DistributorView 
{
	public static void addDetail()
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the Distributor ID");
		String distributorId=sc.nextLine();
		
		System.out.println("Enter the Distributor Name");
		String distributorName=sc.nextLine();
		
		System.out.println("Enter the Distributor Phone No");
		String distributorPhoneNo=sc.nextLine();
		
		System.out.println("Enter the Distributor Email");
		String distributorEmail=sc.nextLine();
		
		new DistributorControl().fun(distributorId,distributorName,distributorPhoneNo,distributorEmail);
		
	}
	public static void file()
	{
		ArrayList<Distributor> arr=new ArrayList(); 
		Distributor rm=null;
		try 
		{
			FileOutputStream fos = new FileOutputStream("C:\\Check.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(arr);
			oos.close();
			fos.close();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
  public static void main(String[] args) 
  {
		file();
		addDetail();
  }
}
