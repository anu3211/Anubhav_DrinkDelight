package Order;

public class Distributor 
{
	private String distributorId;
	private String distributorName;
	private String distributorPhoneNo;
	private String distributorEmail;
	
	public Distributor(String distributorId, String distributorName, String distributorPhoneNo,
			String distributorEmail) 
	{
		super();
		this.distributorId = distributorId;
		this.distributorName = distributorName;
		this.distributorPhoneNo = distributorPhoneNo;
		this.distributorEmail = distributorEmail;
	}

	public String getDistributorId() {
		return distributorId;
	}

	public void setDistributorId(String distributorId) {
		this.distributorId = distributorId;
	}

	public String getDistributorName() {
		return distributorName;
	}

	public void setDistributorName(String distributorName) {
		this.distributorName = distributorName;
	}

	public String getDistributorPhoneNo() {
		return distributorPhoneNo;
	}

	public void setDistributorPhoneNo(String distributorPhoneNo) {
		this.distributorPhoneNo = distributorPhoneNo;
	}

	public String getDistributorEmail() {
		return distributorEmail;
	}

	public void setDistributorEmail(String distributorEmail) {
		this.distributorEmail = distributorEmail;
	}
	
	
		
}
