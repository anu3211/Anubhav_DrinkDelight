package Order;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class ProductOrderView 
{
	public void view()
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the orderId of the Order");
		String orderId=sc.nextLine();
		
		System.out.println("Enter the productId of the Order");
		String productId=sc.nextLine();
		
		System.out.println("Enter the Order Date");
		String sDate1=sc.nextLine();  
		try
		{
		Date orderDate=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
		}
		catch(Exception e)
		{
		System.out.println("Wrong Date input");
		}
		
		System.out.println("Enter the Delivery Date");
		String sDate2=sc.nextLine();  
		try
		{
		Date deliveryDate=new SimpleDateFormat("dd/MM/yyyy").parse(sDate2);
		}
		catch(Exception e)
		{
		System.out.println("Wrong Date input");
		}
		
		System.out.println("Enter the total Price");
		double price = sc.nextDouble();
		
		System.out.println("Enter the customerId of the Order");
		String customerId=sc.nextLine();
		
		System.out.println("Enter the orderQuantity");
		int orderQuantity=sc.nextInt();
	}
}
